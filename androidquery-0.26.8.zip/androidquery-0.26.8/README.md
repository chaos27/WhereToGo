Welcome to the androidquery GitHub home.

Click [here](http://code.google.com/p/android-query/wiki/AsyncAPI) for wiki at GoogleCode
or visit:
http://code.google.com/p/android-query/wiki/AsyncAPI

<<<<<<< HEAD
Click here to help out:
=======
>>>>>>> 7434e46bbf78506fa8f91518058cb26ed47597b8
<a href='https://pledgie.com/campaigns/22663'><img alt='Click here to lend your support to: AndroidQuery and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/22663.png?skin_name=chrome' border='0' ></a>